const prisma = require('./db');
const { ADMIN_IDS } = require('./config');

async function ensureUser(ctx, next) {
  if (!ctx.from) return next();

  const telegramId = BigInt(ctx.from.id);
  const isAdmin = ADMIN_IDS.includes(telegramId);

  let user = await prisma.user.findUnique({ where: { telegramId } });
  if (!user) {
    user = await prisma.user.create({
      data: {
        telegramId,
        username: ctx.from.username || null,
        firstName: ctx.from.first_name || null,
        isAdmin,
      },
    });
  } else if (user.isAdmin !== isAdmin) {
    user = await prisma.user.update({ where: { telegramId }, data: { isAdmin } });
  }

  ctx.state.user = user;
  ctx.state.lang = user.languageCode || 'en';
  return next();
}

module.exports = { ensureUser };
