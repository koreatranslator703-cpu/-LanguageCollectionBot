# @LanguageCollectionBot

A Telegram bot for collecting AI-language-project applications from contributors
and vendors worldwide, with a full admin dashboard, dynamic per-project
questions, file uploads, applicant status tracking, broadcasts, exports, and a
multi-language interface.

## Stack

- **Node.js + Telegraf 4** — bot framework (long polling, no webhook needed)
- **PostgreSQL + Prisma** — database (Users, Projects, Questions, Applications,
  Answers, Files, Broadcasts, Sessions)
- **Express** — a one-route "keep-alive" server so Railway sees the process as
  healthy (the bot itself runs on long polling, not HTTP)

## Features implemented

1. Welcome screen with a Start button
2. Unlimited admin-created Projects, no code changes required
3. Standard applicant questions (Full Name, Country, Native Language, etc.)
4. File uploads: Audio, ZIP, CSV, Excel, PDF, Images, Videos
5. Dynamic, per-project custom questions defined by the admin
6. Admin Dashboard: create/edit/delete projects, statistics, applicants,
   broadcast, export CSV/Excel/JSON
7. Applicant status: Pending, Under Review, Approved, Rejected, Need More Info
8. Admin can message any applicant directly (e.g. approval notices)
9. Broadcast a message to every user who has started the bot
10. Multi-language interface (14 languages included) — adding a language is a
    JSON file, not a code change

## Project structure

```
prisma/schema.prisma        Database schema
src/bot.js                  Entry point — wires everything together
src/config.js                Env vars + core question definitions
src/db.js                    Prisma client
src/session.js                Postgres-backed session store (survives restarts)
src/middlewares.js            Ensures a User row exists + flags admins
src/keyboards.js              Shared inline-keyboard builders
src/i18n/                     Translation loader + one JSON file per language
src/handlers/start.js         Welcome + language selection
src/handlers/projects.js      Project list + project detail
src/scenes/applyScene.js      The application wizard (questions + uploads)
src/scenes/adminCreateProjectScene.js
src/scenes/adminEditProjectScene.js
src/scenes/adminBroadcastScene.js
src/scenes/adminMessageApplicantScene.js
src/handlers/admin/           Dashboard, applicants, stats, export
```

## 1. Create the bot with BotFather

1. Message [@BotFather](https://t.me/BotFather) → `/newbot`
2. Set the username to `LanguageCollectionBot` (or whatever is still available)
3. Copy the token it gives you — you'll need it as `BOT_TOKEN`

## 2. Get your Telegram numeric ID (to become an admin)

Message [@userinfobot](https://t.me/userinfobot) — it replies with your
numeric ID. Put it in `ADMIN_IDS` (comma-separated if more than one admin).

## 3. Push this project to GitHub

```bash
cd telegram-bot
git init
git add .
git commit -m "Initial commit - LanguageCollectionBot"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

## 4. Deploy on Railway

1. Go to [railway.app](https://railway.app) → **New Project** → **Deploy from
   GitHub repo** → select your repo
2. Click **+ New** → **Database** → **Add PostgreSQL**. Railway creates a
   `DATABASE_URL` variable automatically.
3. Open your bot service → **Variables** tab → add:
   - `BOT_TOKEN` = the token from BotFather
   - `ADMIN_IDS` = your numeric Telegram ID(s), comma-separated
   - `DATABASE_URL` — reference the Postgres plugin's variable (Railway lets
     you do this with a variable reference, e.g. `${{Postgres.DATABASE_URL}}`)
4. Railway will run `npm install` (which runs `prisma generate` via
   `postinstall`) and then `npm start`.
5. **Run the first migration** — open the Railway service's shell (or run
   locally with `DATABASE_URL` pointed at the Railway Postgres instance) and
   run:
   ```bash
   npx prisma migrate deploy
   ```
   If you haven't created a migration yet, generate one first from your local
   machine (with `DATABASE_URL` pointing at Railway's Postgres, or a local
   Postgres for development):
   ```bash
   npx prisma migrate dev --name init
   ```
   Commit the generated `prisma/migrations` folder to GitHub so future
   deploys can just run `migrate deploy`.
6. Once deployed, message your bot on Telegram — send `/start`.

## 5. Local development

```bash
npm install
cp .env.example .env   # fill in BOT_TOKEN, ADMIN_IDS, DATABASE_URL
npx prisma migrate dev --name init
npm start
```

## How the admin adds a new project (no code changes)

1. Send `/admin` to the bot (must be one of the `ADMIN_IDS`)
2. Tap **➕ Create Project**
3. Enter the project title, then a description (or Skip)
4. Add as many custom questions as you like — for each one, choose **Free
   text** or **Multiple choice** (and supply comma-separated options for
   choice questions), then tap **Done** when finished
5. The project instantly appears in **📋 Available Projects** for all users

Every applicant is always asked the standard fields (Full Name, Country,
Native Language, Other Languages, Email, Telegram Username, Company/
Freelancer, Available Hours, Experience, Expected Rate, Delivery Time) first,
followed by the project's custom questions, then a file-upload step.

## Adding a new bot language

1. Copy `src/i18n/locales/en.json` to `src/i18n/locales/<code>.json`
2. Translate the values (keep the `{placeholders}` and `\n` as-is)
3. Add `{ code: '<code>', name: '<Language Name>' }` to `SUPPORTED_LANGUAGES`
   in `src/config.js`

No other code changes are needed — the language picker and every message
automatically pick it up. Any string missing from a translation file falls
back to English automatically.

## Notes & things worth knowing

- **Sessions** are stored in Postgres (`Session` table) so in-progress
  applications and admin wizards survive a Railway redeploy or restart.
- **Files** are stored by their Telegram `file_id` only (not downloaded to
  disk) — Telegram hosts the actual file. You can fetch them any time via the
  Bot API (`getFile`) using the stored `file_id`, e.g. from the exported CSV/
  Excel/JSON.
- **Broadcasts** only reach users who have pressed Start on the bot at least
  once (Telegram bots cannot message people who haven't started a
  conversation with them).
- To promote/demote an admin, just edit `ADMIN_IDS` and redeploy — the bot
  re-syncs the `isAdmin` flag on every message from that user.
