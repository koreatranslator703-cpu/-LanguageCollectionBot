function classifyDocument(fileName = '', mimeType = '') {
  const name = (fileName || '').toLowerCase();
  const mime = (mimeType || '').toLowerCase();

  if (name.endsWith('.zip') || name.endsWith('.rar') || name.endsWith('.7z') || mime.includes('zip')) {
    return 'zip';
  }
  if (name.endsWith('.csv') || mime.includes('csv')) return 'csv';
  if (name.endsWith('.xlsx') || name.endsWith('.xls') || mime.includes('spreadsheet') || mime.includes('excel')) {
    return 'excel';
  }
  if (name.endsWith('.pdf') || mime.includes('pdf')) return 'pdf';
  if (mime.startsWith('audio/') || name.endsWith('.mp3') || name.endsWith('.wav') || name.endsWith('.m4a')) {
    return 'audio';
  }
  if (mime.startsWith('video/') || name.endsWith('.mp4') || name.endsWith('.mov')) return 'video';
  if (mime.startsWith('image/') || name.endsWith('.jpg') || name.endsWith('.jpeg') || name.endsWith('.png')) {
    return 'image';
  }
  return 'document';
}

module.exports = { classifyDocument };
